package de.logic.data.members;

import de.logic.data.DataGame;
import java.io.Serializable;

public class MoralOfficer extends CrewMember implements Serializable{
    
    public MoralOfficer(DataGame dataGame) {
        super(dataGame, 1, 1);
    }
    
    public MoralOfficer(DataGame dataGame, int color) {
        super(dataGame, 1, 1, color);
    }

    @Override
    public String getName() {
        return "MoralOfficer";
    }
}

